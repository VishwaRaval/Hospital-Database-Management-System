<html>
  <body>
      <link rel="stylesheet" href="style.css">
      <form method="post" action="Proc_Func_Process.php">
		
Enter Day of the Week (as 1-7 from Sunday to Monday)  :<br>
		<input type="text" name="dayno">
		<br>
  <input type="submit" name="save" value="submit">
                <a class="btn btn-link ml-2" href="welcome.php">Cancel</a>
     </form>
  </body>
</html>


