<?php
    $host = 'localhost';
    $dbname = 'HospitalP';
    $username = 'root';
    $password = 'root';